var searchData=
[
  ['main_12',['main',['../ps__1_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'ps_1.c']]],
  ['max_5fmin_13',['max_min',['../ps__1__utils_8c.html#a7c398941fba42d83e3b3d171333bf0a2',1,'ps_1_utils.c']]]
];
