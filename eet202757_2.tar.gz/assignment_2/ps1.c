/*! 
* \author Madhur Malik
* \version 1.0
* \date Oct 13 2020
* code for problem statement 1
*/

#include<stdio.h>
#include<stdlib.h>

/* print_arr(int Arr[][], int i);
int even_nos(int Arr[][], int i);
void per_sq(int Arr[][], int i);
void indl_prime(int Arr[][], int i);
void  max_min(int Arr[][], int i);

void print_arr(int Arr[][],int i){
    int k,j =0;
    for (k = 0; k <= i; k++)
    {
        for ( j = 0; j <=i; j++)
        {
            printf("%d  ", Arr[k][j] );
        }
        printf("\n");
        
    }

    
}
*/
int main(void)
{
    int i,j,k,ele = 0;  // ele - number of rows and columns

    printf("Enter the number of rows and columns you want in the matrix.  ");
    scanf( "%d", &k);
    int Arr[k][k];  //Initialise the array

    /* input the elements to the array*/

    for (i = 0; i < k; ++i)
    {
        for ( j = 0; j <k; ++j)
        {
            printf("Enter Arr[(%d,%d] element ", (i+1), (j+1) );
            scanf("%d", &Arr[i][j]);
        }
        
    }

    /* Code to print the elements*/

    i=0;  //index variables
    j=0;

    for ( i = 0; i <k; ++i)
    {
        for ( j = 0; j <k; ++j)
        {
            printf("%d ", Arr[i][j] );
        }
        printf("\n");
        
    }

    // code to check the number of even numbers */

    int l=0;
    j=0;
    i=0;

    for ( l = 0; l <k; l++)
    {
        for ( j = 0; j <k; j++)
        {
            if (Arr[l][j]%2 == 0) //check whether the numebr is even
            {
                i++;   //increase the count if the number is even
            }
            
        }
        
    }
    printf("\n\nNumber of Even Numbers in the array is : %d \n", i);

    /*! code to find the perfect squares if any across both diagonals */
    
    printf("\nChecking the diagonals for perfect squares");
    i,j,l =0;
    int m,n,p = 0;

    for (i = 0; i <k ; ++i)
    {
        for (j = 0; j <k; j++)
        {
           if (i==j)
           {
               m = Arr[i][j];  //main diagonal element
               for (l=1; l<m;l++)
                {
                    if (l*l == m)  //checking for perfect squares
                    {
                    printf("\nThe perfect square in main diagonal is : %d ", m);
                    n=1;     //counter to check whether perfect squares exist or not
                    }
                }
           }
        }
    }

    for (i = 0; i <k; i++)
    {
       for (j = 0; j <k; j++)
        {
           if ((i + j) == (k-1))
           {
               p = Arr[i][j];  //secondary diagonal element
               for (l=1; l<p;l++)
                {
                    if (l*l == p)  //checking for perfect squares
                    {
                    printf("\nThe perfect squares in secondary diagonal is : %d ", p);
                    n=1;     //counter to check whether perfect squares exist or not
                    }
                }
          }
        }
    }
       
    

    if (n==0)
    {
        printf("\nNo Number statisfies the criteria");
    }

    /*! code to find the individual prime digits */

    i,j,n =0;
    int max,min = 0;

    for ( n = 0; n <k; n++)
    {
        for ( j = 0; j <k; j++)
        { while (Arr[n][j]>0)
            {
                i = Arr[n][j]%10;
                if( i ==2 || i ==3 || i ==5 || i== 7)    ///Digit is prime
                {
                    if (Arr[n][j] > max)
                    {
                        max = Arr[n][j];                       ///store the greater number
                    }else
                     {
                        min= Arr[n][j];               /// store the smaller number
                     }
                }
                Arr[n][j] = Arr[n][j]/10;
            }
        }
    }
    
    printf("\nThe Greatest Number with prime digits is : %d", max);
    printf("\nThe smallest Number with prime digits is : %d", min);
        
    
    /*! code to find the global maxima and minima in the matrix */

    j,n=0;
    int gmax, gmin;
    gmax= Arr[0][0];
    gmin = Arr[0][0];
    for ( n = 0; n <k; n++)
    {
        for ( j = 0; j <k; j++)
        {
            
            if ((Arr[n][j]) > gmax ) //check whether the number is greater than the first element
            {
               gmax= Arr[n][j];  //change the  number to be checked against
              
            }
            if (Arr[n][j] < gmin)
            {
                gmin= Arr[n][j];
                
            }   
        }
        
    }
    printf("\nThe maximum number in the array is : %d ", gmax);
    printf("\nThe minimum number in the array is : %d ", gmin);
    
    return 0;

}
    